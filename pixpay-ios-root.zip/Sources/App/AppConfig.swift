import Foundation

enum AppConfig {
    /// Ganti dengan alamat server HTTPS kamu, tanpa garis miring di akhir.
    static let apiBase = "https://GANTI-DOMAIN-SERVER-ANDA"

    static let banks = ["BCA", "BRI", "BNI", "Mandiri", "BSI", "CIMB Niaga", "Permata", "Danamon", "Maybank", "SeaBank", "Jago", "BTN", "Panin", "Mega"]
    static let vaBanks = ["BCA", "BRI", "BNI", "Mandiri", "BSI", "Permata", "CIMB Niaga", "Danamon", "Maybank"]
    static let categories = ["Makanan", "Belanja", "Tagihan", "Hiburan", "Transport", "Lainnya"]

    static let minTopup = 10_000.0
    static let maxTopup = 2_000_000.0
    static let minTransfer = 1_000.0
    static let maxTransfer = 25_000_000.0
    static let minWithdraw = 10_000.0
}
