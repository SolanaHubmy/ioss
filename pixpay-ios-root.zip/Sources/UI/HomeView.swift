import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var hideBalance = false
    @State private var selected: Tx?

    var body: some View {
        List {
            Section {
                greetingRow
                balanceCard
            }
            if store.cfg.mt == 1 {
                Section {
                    Label("Layanan sedang dalam pemeliharaan.", systemImage: "wrench.and.screwdriver")
                        .foregroundStyle(.orange)
                }
            }
            if !store.cfg.an.isEmpty {
                Section {
                    Label(store.cfg.an, systemImage: "megaphone")
                        .font(.subheadline)
                }
            }
            Section {
                quickGrid
                    .padding(.vertical, 4)
            }
            Section {
                if store.transactions.isEmpty {
                    Text("Belum ada transaksi").foregroundStyle(.secondary)
                }
                ForEach(store.transactions.prefix(5)) { tx in
                    Button {
                        selected = tx
                    } label: {
                        TxRow(tx: tx)
                    }
                    .buttonStyle(.plain)
                }
            } header: {
                HStack {
                    Text("Transaksi terbaru")
                    Spacer()
                    NavigationLink("Lihat semua") { HistoryView() }
                        .font(.subheadline)
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("Beranda")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    Task { await store.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
            }
        }
        .refreshable { await store.refresh() }
        .task { await store.refresh() }
        .sheet(item: $selected) { tx in
            NavigationStack { TxDetailView(tx: tx) }
        }
    }

    private var greetingRow: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(greeting)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(store.user.name ?? "Pengguna")
                .font(.title2.weight(.bold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 4..<11: return "Selamat pagi"
        case 11..<15: return "Selamat siang"
        case 15..<18: return "Selamat sore"
        default: return "Selamat malam"
        }
    }

    private var balanceCard: some View {
        let totals = Money.monthTotals(store.transactions, offset: 0)
        return VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Total saldo")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.85))
                Spacer()
                Button {
                    withAnimation(.easeInOut) { hideBalance.toggle() }
                } label: {
                    Image(systemName: hideBalance ? "eye.slash.fill" : "eye.fill")
                        .foregroundStyle(.white)
                }
                .buttonStyle(.plain)
            }
            Text(hideBalance ? "Rp••••••" : Money.rp(store.balance))
                .font(.system(size: 32, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
                .contentTransition(.numericText())
            HStack(alignment: .top) {
                miniStat("Masuk bulan ini", Money.rp(totals.masuk))
                Spacer()
                miniStat("Keluar bulan ini", Money.rp(totals.keluar))
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(colors: [Color.brand, Color.brand.opacity(0.75)],
                           startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .listRowInsets(EdgeInsets())
        .listRowBackground(Color.clear)
    }

    private func miniStat(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.8))
            Text(value)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
        }
    }

    private var quickGrid: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 4), spacing: 16) {
            NavigationLink { TopupView() } label: { QuickTile(title: "Isi saldo", icon: "plus.circle.fill") }
            NavigationLink { TransferView() } label: { QuickTile(title: "Kirim", icon: "paperplane.fill") }
            NavigationLink { ReceiveView() } label: { QuickTile(title: "Terima", icon: "qrcode") }
            NavigationLink { WithdrawView() } label: { QuickTile(title: "Tarik", icon: "banknote") }
            NavigationLink { ScanView() } label: { QuickTile(title: "Bayar QRIS", icon: "qrcode.viewfinder") }
            QuickTile(title: "Tagihan", icon: "doc.text", locked: true)
            NavigationLink { ReportView() } label: { QuickTile(title: "Laporan", icon: "chart.bar") }
            NavigationLink { HelpView() } label: { QuickTile(title: "Bantuan", icon: "questionmark.circle") }
        }
    }
}

struct QuickTile: View {
    let title: String
    let icon: String
    var locked = false

    var body: some View {
        VStack(spacing: 6) {
            ZStack {
                Circle()
                    .fill(locked ? Color(.systemGray5) : Color.brandSoft)
                    .frame(width: 52, height: 52)
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(locked ? Color.gray : Color.brand)
            }
            Text(title)
                .font(.caption)
                .multilineTextAlignment(.center)
                .lineLimit(2)
            if locked {
                Text("Coming soon")
                    .font(.system(size: 9))
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity)
    }
}
