import SwiftUI
import UIKit

struct DetailRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label).foregroundStyle(.secondary)
            Spacer(minLength: 12)
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
    }
}

struct TxRow: View {
    let tx: Tx

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(tx.ti ?? "Transaksi")
                    .font(.body.weight(.semibold))
                    .lineLimit(1)
                Text(tx.status == "ok" ? Money.date(tx.ts) : "\(Money.date(tx.ts)) • \(Money.status(tx.status))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            Text((tx.amount > 0 ? "+" : "") + Money.rp(tx.amount))
                .font(.body.weight(.bold))
                .foregroundStyle(tx.amount > 0 ? Color.okGreen : Color.primary)
        }
        .padding(.vertical, 4)
    }
}

struct PinSheet: View {
    let title: String
    let onConfirm: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var pin = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("PIN 6 angka", text: $pin)
                        .keyboardType(.numberPad)
                        .onChange(of: pin) { value in
                            pin = String(value.filter(\.isNumber).prefix(6))
                        }
                } footer: {
                    Text("Masukkan PIN kamu untuk mengonfirmasi transaksi.")
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Batal") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Konfirmasi") { onConfirm(pin) }
                        .disabled(pin.count != 6)
                }
            }
        }
        .presentationDetents([.medium])
    }
}

struct AmountField: View {
    let label: String
    @Binding var text: String

    var body: some View {
        HStack {
            Text("Rp").foregroundStyle(.secondary)
            TextField(label, text: $text)
                .keyboardType(.numberPad)
                .font(.title3.weight(.semibold))
                .onChange(of: text) { value in
                    let digits = String(value.filter(\.isNumber).prefix(10))
                    if digits != value { text = digits }
                }
        }
    }
}

struct QuickAmounts: View {
    let values: [Double]
    let onPick: (Double) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(values, id: \.self) { value in
                    Button(Money.rp(value)) { onPick(value) }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                }
            }
        }
    }
}

struct QRImageView: View {
    let source: String

    var body: some View {
        if source.hasPrefix("http"), let url = URL(string: source) {
            AsyncImage(url: url) { image in
                image.resizable().interpolation(.none).scaledToFit()
            } placeholder: {
                ProgressView()
            }
        } else if source.hasPrefix("data:"),
                  let comma = source.firstIndex(of: ","),
                  let data = Data(base64Encoded: String(source[source.index(after: comma)...])),
                  let image = UIImage(data: data) {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
        } else if let image = QRCodeImage.make(source) {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
        } else {
            Text("QR tidak dapat ditampilkan").foregroundStyle(.secondary)
        }
    }
}
