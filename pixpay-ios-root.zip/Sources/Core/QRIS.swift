import Foundation

enum CodeKind {
    case pixpay
    case qris
}

struct PayCode: Identifiable, Equatable {
    let kind: CodeKind
    let name: String
    let city: String
    let amount: Double
    let fixed: Bool
    let raw: String
    let toPhone: String

    var id: String { raw }
}

enum QRIS {
    static func parse(_ input: String) -> PayCode? {
        let s = input.trimmingCharacters(in: .whitespacesAndNewlines)
        if let phone = pixpayPhone(s) {
            return PayCode(kind: .pixpay, name: phone, city: "", amount: 0, fixed: false, raw: s, toPhone: phone)
        }
        guard s.hasPrefix("000201"), s.count >= 30 else { return nil }
        guard crc16(String(s.dropLast(4))) == s.suffix(4).uppercased() else { return nil }

        let chars = Array(s)
        var tags: [String: String] = [:]
        var i = 0
        while i < chars.count {
            guard i + 4 <= chars.count else { return nil }
            let key = String(chars[i..<(i + 2)])
            guard key.allSatisfy({ $0.isNumber }),
                  let length = Int(String(chars[(i + 2)..<(i + 4)])),
                  i + 4 + length <= chars.count else { return nil }
            tags[key] = String(chars[(i + 4)..<(i + 4 + length)])
            i += 4 + length
        }
        guard tags["58"] == "ID",
              let name = tags["59"]?.trimmingCharacters(in: .whitespaces),
              !name.isEmpty else { return nil }

        let amount = (Double(tags["54"] ?? "") ?? 0).rounded()
        return PayCode(
            kind: .qris,
            name: name,
            city: tags["60"]?.trimmingCharacters(in: .whitespaces) ?? "",
            amount: amount,
            fixed: tags["54"] != nil && amount > 0,
            raw: s,
            toPhone: ""
        )
    }

    private static func pixpayPhone(_ s: String) -> String? {
        var value = s
        if value.lowercased().hasPrefix("pixpay:") {
            value = String(value.dropFirst(7))
        }
        guard value.first == "0", (10...14).contains(value.count), value.allSatisfy({ $0.isNumber }) else {
            return nil
        }
        return value
    }

    static func crc16(_ text: String) -> String {
        var crc: UInt16 = 0xFFFF
        for byte in text.utf8 {
            crc ^= UInt16(byte) << 8
            for _ in 0..<8 {
                crc = (crc & 0x8000) != 0 ? ((crc << 1) ^ 0x1021) : (crc << 1)
            }
        }
        return String(format: "%04X", crc)
    }
}
