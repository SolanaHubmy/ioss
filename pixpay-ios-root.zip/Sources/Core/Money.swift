import Foundation

enum Money {
    static func rp(_ value: Double) -> String {
        let n = Int(value.rounded())
        var grouped = ""
        for (index, ch) in String(abs(n)).reversed().enumerated() {
            if index > 0 && index % 3 == 0 { grouped.append(".") }
            grouped.append(ch)
        }
        return (n < 0 ? "-" : "") + "Rp" + String(grouped.reversed())
    }

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "id_ID")
        f.dateFormat = "d MMM yyyy, HH:mm"
        return f
    }()

    static func date(_ ms: Double?) -> String {
        dateFormatter.string(from: Date(timeIntervalSince1970: (ms ?? 0) / 1000))
    }

    static func status(_ st: String) -> String {
        switch st {
        case "ok": return "Berhasil"
        case "pending": return "Diproses"
        case "fail": return "Gagal"
        default: return st
        }
    }

    static func tarikAdmin(amount: Double, cfg: Cfg) -> Double {
        amount <= cfg.small ? cfg.feeTarikKecil : cfg.feeTarik
    }

    static func pajak(admin: Double, cfg: Cfg) -> Double {
        (admin * cfg.pajakPct / 100).rounded()
    }

    static func monthRange(offset: Int) -> (start: Date, end: Date) {
        let cal = Calendar.current
        let base = cal.date(byAdding: .month, value: offset, to: Date()) ?? Date()
        let start = cal.date(from: cal.dateComponents([.year, .month], from: base)) ?? base
        let end = cal.date(byAdding: .month, value: 1, to: start) ?? start
        return (start, end)
    }

    static func monthTotals(_ txs: [Tx], offset: Int) -> (masuk: Double, keluar: Double) {
        let range = monthRange(offset: offset)
        let rows = txs.filter { $0.status != "fail" && $0.date >= range.start && $0.date < range.end }
        let masuk = rows.filter { $0.amount > 0 }.reduce(0.0) { $0 + $1.amount }
        let keluar = rows.filter { $0.amount < 0 }.reduce(0.0) { $0 - $1.amount }
        return (masuk: masuk, keluar: keluar)
    }
}
