import SwiftUI

struct HistoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var mode = 0
    @State private var selected: Tx?

    var body: some View {
        List {
            Section {
                Picker("Filter", selection: $mode) {
                    Text("Semua").tag(0)
                    Text("Masuk").tag(1)
                    Text("Keluar").tag(2)
                }
                .pickerStyle(.segmented)
            }
            Section {
                if filtered.isEmpty {
                    Text("Belum ada transaksi").foregroundStyle(.secondary)
                }
                ForEach(filtered) { tx in
                    Button {
                        selected = tx
                    } label: {
                        TxRow(tx: tx)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .navigationTitle("Riwayat")
        .refreshable { await store.refresh() }
        .task { await store.refresh() }
        .sheet(item: $selected) { tx in
            NavigationStack { TxDetailView(tx: tx) }
        }
    }

    private var filtered: [Tx] {
        switch mode {
        case 1: return store.transactions.filter { $0.amount > 0 }
        case 2: return store.transactions.filter { $0.amount < 0 }
        default: return store.transactions
        }
    }
}

struct TxDetailView: View {
    let tx: Tx
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        List {
            Section {
                DetailRow(label: "Jumlah", value: Money.rp(tx.amount))
                DetailRow(label: "Biaya", value: Money.rp(tx.fee ?? 0))
                DetailRow(label: "Total", value: Money.rp(tx.total ?? 0))
                DetailRow(label: "Status", value: Money.status(tx.status))
                DetailRow(label: "Waktu", value: Money.date(tx.ts))
                if let category = tx.c, !category.isEmpty {
                    DetailRow(label: "Kategori", value: category)
                }
                if let note = tx.note, !note.isEmpty {
                    DetailRow(label: "Catatan", value: note)
                }
                if let ref = tx.ref, !ref.isEmpty {
                    DetailRow(label: "Referensi", value: ref)
                }
                if let target = tx.m?.nm, !target.isEmpty {
                    DetailRow(label: "Tujuan", value: target)
                }
                if let va = tx.va, !va.isEmpty {
                    DetailRow(label: "Nomor VA", value: va)
                }
                DetailRow(label: "ID", value: tx.id)
            }
        }
        .navigationTitle(tx.ti ?? "Detail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Tutup") { dismiss() }
            }
        }
    }
}
