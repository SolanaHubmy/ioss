import SwiftUI

struct ReportView: View {
    @EnvironmentObject private var store: AppStore
    @State private var offset = 0

    private var title: String {
        let range = Money.monthRange(offset: offset)
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "id_ID")
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: range.start)
    }

    private var totals: (masuk: Double, keluar: Double) {
        Money.monthTotals(store.transactions, offset: offset)
    }

    private var categories: [(name: String, value: Double)] {
        let range = Money.monthRange(offset: offset)
        let outs = store.transactions.filter {
            $0.status != "fail" && $0.amount < 0 && $0.date >= range.start && $0.date < range.end
        }
        let grouped = Dictionary(grouping: outs) { tx -> String in
            let category = tx.c ?? ""
            return category.isEmpty ? "Lainnya" : category
        }
        return grouped
            .map { (name: $0.key, value: $0.value.reduce(0.0) { $0 + abs($1.amount) }) }
            .sorted { $0.value > $1.value }
    }

    var body: some View {
        List {
            Section {
                HStack {
                    Button {
                        offset -= 1
                    } label: {
                        Image(systemName: "chevron.left")
                    }
                    Spacer()
                    Text(title).font(.headline)
                    Spacer()
                    Button {
                        offset += 1
                    } label: {
                        Image(systemName: "chevron.right")
                    }
                    .disabled(offset >= 0)
                }
                .buttonStyle(.borderless)
            }
            Section("Ringkasan") {
                DetailRow(label: "Masuk", value: Money.rp(totals.masuk))
                DetailRow(label: "Keluar", value: Money.rp(totals.keluar))
                DetailRow(label: "Selisih", value: Money.rp(totals.masuk - totals.keluar))
            }
            Section("Pengeluaran per kategori") {
                let items = categories
                let total = max(items.reduce(0.0) { $0 + $1.value }, 1)
                if items.isEmpty {
                    Text("Belum ada pengeluaran bulan ini").foregroundStyle(.secondary)
                }
                ForEach(items, id: \.name) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(item.name)
                            Spacer()
                            Text(Money.rp(item.value)).foregroundStyle(.secondary)
                        }
                        ProgressView(value: item.value, total: total)
                            .tint(Color.brand)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Laporan")
        .task { await store.refresh() }
    }
}
