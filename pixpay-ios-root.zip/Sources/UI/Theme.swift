import SwiftUI
import UIKit

extension Color {
    static let brand = Color(red: 0.06, green: 0.42, blue: 0.29)
    static let brandSoft = Color(red: 0.89, green: 0.94, blue: 0.91)
    static let okGreen = Color(red: 0.09, green: 0.54, blue: 0.35)
    static let subtleFill = Color(uiColor: .secondarySystemBackground)
}
