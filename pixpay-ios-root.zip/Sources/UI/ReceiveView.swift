import SwiftUI
import UIKit

struct ReceiveView: View {
    @EnvironmentObject private var store: AppStore
    @State private var copied = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                if let qr = QRCodeImage.make("PIXPAY:\(store.user.phone ?? "")") {
                    Image(uiImage: qr)
                        .interpolation(.none)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 240, height: 240)
                }
                Text(store.user.name ?? "")
                    .font(.title3.weight(.bold))
                Text(store.user.phone ?? "")
                    .font(.headline)
                    .foregroundStyle(.secondary)
                Text("Minta pengirim memindai QR ini di Bayar QRIS, atau masukkan nomor HP kamu.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                Button {
                    UIPasteboard.general.string = store.user.phone ?? ""
                    copied = true
                } label: {
                    Label(copied ? "Nomor tersalin" : "Salin nomor", systemImage: "doc.on.doc")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .navigationTitle("Terima uang")
        .navigationBarTitleDisplayMode(.inline)
    }
}
