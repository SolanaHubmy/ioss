import SwiftUI

@main
struct PixpayApp: App {
    @StateObject private var store = AppStore()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .tint(Color.brand)
                .task { await store.boot() }
                .onChange(of: scenePhase) { phase in
                    if phase == .active, store.loggedIn {
                        Task { await store.refresh() }
                    }
                }
        }
    }
}
