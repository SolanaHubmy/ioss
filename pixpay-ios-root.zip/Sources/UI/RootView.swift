import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        Group {
            if store.booting {
                ProgressView()
            } else if store.loggedIn {
                MainTabs()
            } else {
                AuthView()
            }
        }
        .animation(.default, value: store.loggedIn)
    }
}

struct MainTabs: View {
    var body: some View {
        TabView {
            NavigationStack { HomeView() }
                .tabItem { Label("Beranda", systemImage: "house") }
            NavigationStack { HistoryView() }
                .tabItem { Label("Riwayat", systemImage: "clock") }
            NavigationStack { ScanView() }
                .tabItem { Label("QRIS", systemImage: "qrcode.viewfinder") }
            NavigationStack { ReportView() }
                .tabItem { Label("Laporan", systemImage: "chart.bar") }
            NavigationStack { ProfileView() }
                .tabItem { Label("Saya", systemImage: "person.crop.circle") }
        }
    }
}
